$('#formAuthentication').on('submit', function (e){
    e.preventDefault();
    if ($(this).valid()){
        let formData = new FormData(this);
        let token = $('meta[name="csrf-token"]').attr('content');
        formData.append('_token', token);

        $.ajax({
            url: '/login',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                window.location.href = '/dashboard';
            },
            error: function(xhr, status, error) {
                if (xhr.responseJSON && xhr.responseJSON.errors && xhr.responseJSON.errors.email) {
                    $('#message').html('<p>' + xhr.responseJSON.errors.email[0] + '</p>');
                } else if (xhr.responseJSON && xhr.responseJSON.message) {
                    $('#message').html('<p>' + xhr.responseJSON.message + '</p>');
                } else {
                    $('#message').html('<p>' + xhr.status + ': ' + xhr.statusText + '</p>');
                }
            }
        });
    }
})
